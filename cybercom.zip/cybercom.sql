-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2021 at 06:40 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cybercom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(100) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(5) NOT NULL,
  `createdDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `userName`, `password`, `status`, `createdDate`) VALUES
(2, 'raj', 'rajraj', 'femal', '0000-00-00'),
(3, 'prince', 'prince', 'male', '0000-00-00'),
(4, 'nirali', 'hello', 'femal', '0000-00-00'),
(11, 'meet ', 'meet', 'male', '2021-02-27'),
(12, 'krunal', '', 'male', '2021-02-27'),
(31, 'raj', 'raj', 'Femal', '2021-03-10');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryId` int(100) NOT NULL,
  `parentId` varchar(100) NOT NULL,
  `pathId` varchar(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryId`, `parentId`, `pathId`, `name`, `status`, `description`) VALUES
(1, '', '1', 'bedroom', 'Disable', 'parent'),
(2, '1', '', 'bed', 'Enable', 'child'),
(3, '1', '', 'bed', 'Enable', 'child'),
(4, '2', '', 'panel bed', 'Disable', 'child'),
(5, '2', '', 'raj', 'Disable', 'asxasx'),
(6, '', '', '', 'Disable', '');

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE `cms` (
  `pageId` int(100) NOT NULL,
  `title` varchar(40) NOT NULL,
  `identifier` varchar(20) NOT NULL,
  `content` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createdDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cms`
--

INSERT INTO `cms` (`pageId`, `title`, `identifier`, `content`, `status`, `createdDate`) VALUES
(3, 'blog', '', 'fasion', 'Disable', '2021-03-09');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerId` int(100) NOT NULL,
  `groupId` varchar(11) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` int(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createdDate` date NOT NULL,
  `updatedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerId`, `groupId`, `firstName`, `lastName`, `email`, `password`, `mobile`, `status`, `createdDate`, `updatedDate`) VALUES
(1, 'retail', 'meet', 'patel', 'patel@gmail.com', 'df421bd994d485f5d58c', 234567890, 'Disable', '2021-02-18', '2021-03-04'),
(5, '', 'hensi', 'solanki', 'hensi@yahoo.com', 'b82e2469ed6e6735a89f', 9876543, 'Enable', '2021-02-18', '2021-03-09'),
(6, '', 'raj', 'kandolia', 'raj@gmail.com', '17c8135080acffd5e3fd', 1234567890, 'Disable', '2021-02-25', '2021-03-09'),
(16, 'retail', 'prince', 'kandolia', 'prince@gmail.com', 'prince', 232342342, 'Disable', '2021-03-02', '2021-03-04'),
(17, 'wholesale', 'krunal', 'ambaliya', 'krunal@gmail.com', 'krunal', 2193273, 'Disable', '2021-03-03', '2021-03-04');

-- --------------------------------------------------------

--
-- Table structure for table `customerbilling`
--

CREATE TABLE `customerbilling` (
  `billingId` int(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(10) NOT NULL,
  `state` varchar(20) NOT NULL,
  `zipcode` int(10) NOT NULL,
  `country` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customergroup`
--

CREATE TABLE `customergroup` (
  `customerGroupId` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createdDate` date NOT NULL,
  `group` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customergroup`
--

INSERT INTO `customergroup` (`customerGroupId`, `name`, `status`, `createdDate`, `group`) VALUES
(6, 'retail', 'Disable', '2021-03-04', ''),
(7, 'wholesale', 'Disable', '2021-03-04', '');

-- --------------------------------------------------------

--
-- Table structure for table `customershipping`
--

CREATE TABLE `customershipping` (
  `shippingId` int(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(10) NOT NULL,
  `state` varchar(10) NOT NULL,
  `zipcode` int(10) NOT NULL,
  `country` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `methodId` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` int(10) NOT NULL,
  `description` varchar(250) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createdAt` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`methodId`, `name`, `code`, `description`, `status`, `createdAt`) VALUES
(2, 'dmart', 123, 'shopping', 'enabled', '2021-02-19'),
(3, 'hospital', 12345, 'bill', 'enabled', '2021-02-19'),
(18, 'bank', 37492, 'sbi', 'Disable', '2021-03-06');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productId` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `discount` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  `description` varchar(250) NOT NULL,
  `createdAt` date NOT NULL,
  `updatedAt` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productId`, `name`, `price`, `discount`, `quantity`, `status`, `description`, `createdAt`, `updatedAt`) VALUES
(72, 'telivision', 50000, 0, 4, 'Disable', 'samsung            ', '2021-03-01', '0000-00-00'),
(73, 'laptop', 80000, 0, 9, 'Disable', 'dell', '2021-03-01', '0000-00-00'),
(74, 'books', 300, 0, 3, 'Disable', 'java           ', '2021-03-01', '0000-00-00'),
(76, 'mobile', 20000, 0, 1, 'Disable', 'redmi                   ', '2021-03-01', '2021-03-04'),
(77, 'headphones', 1000, 0, 3, 'Disable', 'boat             ', '2021-03-01', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `productimage`
--

CREATE TABLE `productimage` (
  `imageId` int(100) NOT NULL,
  `image` varchar(20) NOT NULL,
  `label` varchar(10) NOT NULL,
  `small` varchar(10) NOT NULL,
  `thumb` varchar(10) NOT NULL,
  `base` varchar(10) NOT NULL,
  `gallary` varchar(10) NOT NULL,
  `remove` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `methodId` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` int(10) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `description` varchar(250) NOT NULL,
  `status` varchar(10) NOT NULL,
  `createdAt` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`methodId`, `name`, `code`, `amount`, `description`, `status`, `createdAt`) VALUES
(2, 'aaa', 123456, '1234', 'hello', 'enabled', '2021-02-19'),
(3, 'bbb', 34567, '12345', 'hiii', 'enabled', '2021-02-19'),
(4, 'ccc', 123456, '984433', 'hello', 'enabled', '2021-02-19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryId`);

--
-- Indexes for table `cms`
--
ALTER TABLE `cms`
  ADD PRIMARY KEY (`pageId`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerId`);

--
-- Indexes for table `customerbilling`
--
ALTER TABLE `customerbilling`
  ADD PRIMARY KEY (`billingId`);

--
-- Indexes for table `customergroup`
--
ALTER TABLE `customergroup`
  ADD PRIMARY KEY (`customerGroupId`);

--
-- Indexes for table `customershipping`
--
ALTER TABLE `customershipping`
  ADD PRIMARY KEY (`shippingId`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`methodId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `productimage`
--
ALTER TABLE `productimage`
  ADD PRIMARY KEY (`imageId`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`methodId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cms`
--
ALTER TABLE `cms`
  MODIFY `pageId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `customerbilling`
--
ALTER TABLE `customerbilling`
  MODIFY `billingId` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customergroup`
--
ALTER TABLE `customergroup`
  MODIFY `customerGroupId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customershipping`
--
ALTER TABLE `customershipping`
  MODIFY `shippingId` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `methodId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `productimage`
--
ALTER TABLE `productimage`
  MODIFY `imageId` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `methodId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
