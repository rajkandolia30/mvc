<?php 
class Model_Media_Collection{
	public $data = [];

	public function setData($data = []){
		$this->data = $data;
		return $this;
	}

	public function getData(){
		$this->data;
	}
}