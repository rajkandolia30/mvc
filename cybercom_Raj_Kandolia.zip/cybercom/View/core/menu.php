<div class="option">	  
   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','admin');?>').resetParams().load();">Admin</a>
   	
   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','product');?>').resetParams().load();">Products</a>
  
   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','cms');?>').resetParams().load();">CMSs</a>
  
   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','customer');?>').resetParams().load();">Customers</a>

   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','customerGroup');?>').resetParams().load();">CustomerGroup</a>

   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','category');?>').resetParams().load();">Categories</a>
   
   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','shipping');?>').resetParams().load();">Shipping</a>

   <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','payment');?>').resetParams().load();">Payment</a>

    <a href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('grid','attribute');?>').resetParams().load();">Attribute</a>
</div>