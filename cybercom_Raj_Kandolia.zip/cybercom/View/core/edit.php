<div>
    <h2>Products<h2>
    <hr>
</div>
<table>
	<tr>
		<td>
			<?php echo $this->getTabHtml(); ?>
		</td>
		<td>
			<?php echo $this->getTabContent(); ?>
		</td>
	</tr>
</table>
   
