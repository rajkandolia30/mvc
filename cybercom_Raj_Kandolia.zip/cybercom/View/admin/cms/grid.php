<?php
   $cmss = $this->getCmss();
   $data = $cmss->data;
?>
<div>
    <h2>Cmss</h2>
    <hr>
</div>

<table class="table">
    <tr>
        <th>Page ID</th>
        <th>Title</th>
        <th>Identifier</th>
        <th>Content</th>
        <th>Status</th>
        <th>createdDate</th>
        <th colspan="3">Actions</th>
    </tr>
        <?php   foreach ($data as $key => $value) {?>
                    <tr>
                        <td><?php echo $value->pageId ?></td>
                        <td><?php echo $value->title ?></td>
                        <td><?php echo $value->identifier ?></td>
                        <td><?php echo $value->content ?></td>
                        <td><?php echo $value->status ?></td>
                        <td><?php echo $value->createdDate ?></td>
                        <td>
                            <button class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->pageId])?>').resetParams().load()">Delete</button>
                        </td>
                        <td>
                            <button class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->pageId])?>').resetParams().load()">Update</button>
                        </td>
                    </tr>            
        <?php } ?>
</table>

<div>
    <button class="btn btn-success" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','Cms') ?>').resetParams().load()">Add CMS</button>
</div>