<?php
$payments = $this->getPayments();
$data = $payments->data;
?>
<div>
        <h2>Payments</h2>
        <hr>
</div>

<table class="table">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Code</th>
        <th>Description</th>
        <th>Status</th>
        <th>createdAt</th>
        <th colspan="2">Actions</th>
    </tr>
        <?php   foreach ($data as $key => $value) {?>
                <tr>
                    <td><?php echo $value->methodId ?></td>
                    <td><?php echo $value->name ?></td>
                    <td><?php echo $value->code ?></td>
                    <td><?php echo $value->description ?></td>
                    <td><?php echo $value->status ?></td>
                    <td><?php echo $value->createdAt ?></td>
                    <td>
                        <button type="button" class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->methodId])?>').resetParams().load()">Delete</button>
                    </td>
                    <td>
                        <button type="button" class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->methodId])?>').resetParams().load()">Update</button>
                    </td>
                </tr>            
        <?php } ?>
</table>

<div>
        <button type="button" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','Payment') ?>').resetParams().load()" class="btn btn-success">Add Payment</button>
</div>