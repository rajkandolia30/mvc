<?php
$customers = $this->getCustomers();
$data = $customers->data;
?>
<div>
    <h2>Customers</h2>
    <hr>
</div>

<table class="table">
    <tr>
        <th>ID</th>
        <th>GroupId</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Mobile</th>
        <th>Status</th>
        <th>createdDate</th>
        <th>updatedDate</th>
        <th colspan="2">Actions</th>
    </tr>

        <?php if(!$customers->data): ?>
            <tr>
                <td colspan="11"><center>No record Found</center></td>
            </tr>
        <?php else :
                foreach ($data as $key => $value):?>
                    <tr>
                        <td><?php echo $value->customerId ?></td>
                        <td><?php echo $value->groupId ?></td>
                        <td><?php echo $value->firstName ?></td>
                        <td><?php echo $value->lastName ?></td>
                        <td><?php echo $value->email ?></td>
                        <td><?php echo $value->password ?></td>
                        <td><?php echo $value->mobile ?></td>
                        <td><?php echo $value->status ?></td>
                        <td><?php echo $value->createdDate ?></td>
                        <td><?php echo $value->updatedDate ?></td>
                        <td>
                            <button class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->customerId])?>').resetParams().load()">Delete</button>
                        </td>
                        <td>
                            <button class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->customerId])?>').resetParams().load()">Update</button>
                        </td>
                    </tr>            
        <?php endforeach; endif;?>
</table>

<div>
    <button class="btn btn-success" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','Customer') ?>').resetParams().load()">Add Customer</button>
</div>
