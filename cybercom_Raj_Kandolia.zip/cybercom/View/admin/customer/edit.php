<div>
    <h2>Customers<h2>
    <hr>
</div>

<?php  // echo $this->getTabContent(); ?>
