<?php 
$admins = $this->getAdmins();
$data = $admins->data; 
?>
<div>
    <h2>Admins<h2>
    <hr>
</div>

<div>
	<table class="table">
		<tr>
			<th>Admin ID</th>
			<th>UserName</th>
			<th>Password</th>
			<th>Status</th>
			<th>createdDate</th>
			<th colspan="2">Actions</th>
		</tr>
	        <?php foreach ($data as $key => $value):?>
	            <tr>
		            <td><?php echo $value->adminId ?></td>
		            <td><?php echo $value->userName ?></td>
		            <td><?php echo $value->password ?></td>
		            <td><?php echo $value->status ?></td>
		            <td><?php echo $value->createdDate ?></td>
		            <td>
		                <button class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->adminId])?>').resetParams().load()">Delete</button>
		            </td>
		            <td>
		                <button class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->adminId])?>').resetParams().load()">Update</button>
		            </td>
	            </tr>            
	        <?php endforeach;?>
	</table>
</div>

<div>
	<button href="javascript:void(0)" class="btn btn-success" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','admin');?>').resetParams().load();">Add Admins</button>
</div>