<?php/*  
$attribute = $this->getAttributeOption();
?>
<form action="<?php echo $this->getUrl()->getUrl('update'); ?>" method="post">
	<table id="existingOption">
		<tr>
			<td>
				<button type="button">Update</button>
				<button type="button">Add Option</button>
			</td>
		</tr>
		<?php foreach($attribute->getOption() as $key => $option): ?>
		<tr>
			<td><input type="text" name="exist[<?php echo $optiion->optionId ?>][name]" value="<?php echo $this->option->name ?>"></td>
			<td><input type="text" name="exist[<?php echo $optiion->optionId ?>][sortOrder]" value="<?php echo $this->option->sortOrder ?>"></td>
			<td><button type="button">Remove Option</button></td>
		</tr>
	<?php endforeach; ?>
	</table>	
</form>
<div style="display:none">
	<table id="newOption">
		<tr>
			<td><input type="text" name="name[new][]"></td>
			<td><input type="text" name="sortOrder[new][]"></td>
			<td><input type="submit" name="removeOption[new][]" value="Remove Option"></td>
		</tr>
	</table>
</div>
<script type="text/javascript">
	function addRow(){
		var newOptionTable = document.getElementById('newOption');
		var existingOptionTable = documnet.getElementById('existingOption').children[0];
		existingOptionTable.prepand(newOptionTable.children[0].cloneNode(true));
	}

	function removeRow(button){
		var objectTableRow = button.parentElement.parentElement;
		objectTableRow.remove();
	}
</script>*/?>