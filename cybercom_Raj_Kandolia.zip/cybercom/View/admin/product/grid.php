<?php
$products = $this->getProducts();
$data = $products->data;
?>
<div>
    <h2>Products</h2>
    <hr>
</div>

<table class="table">
    <tr>
        <th>ID</th>     
        <th>Name</th>
        <th>Price</th>
        <th>Discount</th>
        <th>Quatity</th>
        <th>Status</th>
        <th>Description</th>
        <th>createdAt</th>
        <th>updatedAt</th>
        <th colspan="2">Actions</th>
    </tr>
        <?php foreach ($data as $key => $value) {?>
                <tr>
                    <td><?php echo $value->productId ?></td>
                    <td><?php echo $value->name ?></td>
                    <td><?php echo $value->price ?></td>
                    <td><?php echo $value->discount ?></td>
                    <td><?php echo $value->quantity ?></td>
                    <td><?php echo $value->status ?></td>
                    <td><?php echo $value->description ?></td>
                    <td><?php echo $value->createdAt ?></td>
                    <td><?php echo $value->updatedAt ?></td>
                    <td> 
                        <button type="button" class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->productId]);?>').resetParams().load()">Delete</button>
                    </td>
                    <td>
                        <button type="button" class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->productId]);?>').resetParams().load()">Update</button>
                    </td>
                </tr>            
        <?php } ?>
</table>

<div>
    <button href="javascript:void(0)" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','Product') ?>').resetParams().load()" type="button" class="btn btn-success">Add product</button>
</div>