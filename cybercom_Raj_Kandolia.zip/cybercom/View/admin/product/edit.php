<!-- <div>
    <h2>Products<h2>
    <hr>
</div>
<table>
	<tr>
		<td>
			<?php //$this->getTabHtml(); ?>
		</td>
		<td>
			<?php //$this->getTabContent(); ?>
		</td>
	</tr>
</table>
   
 -->

