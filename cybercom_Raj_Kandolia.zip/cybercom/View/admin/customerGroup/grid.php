<?php
$customerGroup = $this->getCustomerGroups();
$data = $customerGroup->data;
?>
<div>
    <h2>Customer Group</h2>
    <hr>
</div>

<table class="table">
    <tr>
        <th>Group ID</th>
        <th>Group</th>
        <th>Status</th>
        <th>createdDate</th>
        <th colspan="2">Actions</th>
    </tr>
        <?php foreach ($data as $key => $value) {?>
                <tr>
                    <td><?php echo $value->customerGroupId ?></td>
                    <td><?php echo $value->name ?></td>
                    <td><?php echo $value->status ?></td>
                    <td><?php echo $value->createdDate ?></td>
                    <td>
                        <button class="btn btn-danger" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('delete',null,['id'=>$value->customerGroupId])?>').resetParams().load()">Delete</button>
                    </td>
                    <td>
                        <button class="btn btn-info" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form',null,['id'=>$value->customerGroupId])?>').resetParams().load()">Update</button>
                    </td>
                </tr>            
        <?php } ?>
</table>

<div class="button">
    <button type="button" onclick="object.setUrl('<?php echo $this->getUrl()->getUrl('form','CustomerGroup',[],true) ?>').resetParams().load()" class="btn btn-success">Add CustomerGroup</button>
</html>