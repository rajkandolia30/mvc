<!-- <div>
    <h2>Categories<h2>
    <hr>
</div>

<form action="<?php //echo $this->getUrl()->getUrl('save','Category');?>" method="POST" id="categoryForm">
    <table>
        <?php //echo $this->getTabContent();?>
    </table>
</form>
 -->