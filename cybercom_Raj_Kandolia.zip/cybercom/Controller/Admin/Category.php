<?php
namespace Controller\Admin;
\Mage::loadFileByClassName('Controller\Core\Admin');
class Category extends \Controller\Core\Admin{
    protected $categories = [];
    protected $category = null;
    protected $model = null;

    public function setModel(){
        try {
            $this->model = \Mage::getModel('Model\Category');
            return $this;
        } catch (Exception $e) {
            echo $e->getMessage();
        }        
    }
    
    public function getModel(){
        try {
                if(!$this->model){
                    $this->setModel();
                }
            return $this->model;
        } catch (Exception $e) {
            echo $e->getMessage();
        }        
    }

    public function gridAction(){
        try {
            $grid = \Mage::getBlock('Block\Admin\Category\Grid')->toHtml();
            $response = [
                'element' => [
                    [
                        'selector' => null,
                        'html' => null
                    ],
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid
                    ]
                ]                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);
        } catch (Exception $e) {
            echo $e->getMessage();
        }       
    }
    
    public function formAction(){
        try{
            $category =  \Mage::getModel('Model\Category');
            $id =  $this->getRequest()->getGet('id');
            $category->load($id);
            $form = \Mage::getBlock('Block\Admin\Category\Edit');
            $form->setTableRow($category);
            $tabs =  \Mage::getBlock('Block\Admin\Category\Edit\Tabs');
            $form = $form->toHtml();
            $response = [
                'element' =>
                    [
                        [
                            'selector' => '#tab',
                            'html' => $tabs
                        ],
                        [
                            'selector' => '#contentHtml',
                            'html' => $form,                    
                        ]
                    ]
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
    
    public function saveAction(){
        try{
            if(!$this->getRequest()->isPost()){
                throw new Exception("Invalid request");
            }
            $category = \Mage::getModel('Model\Category');
            $postData =  $this->getRequest()->getPost('category');
            $categoryId =  $this->getRequest()->getGet('id');
            $categoryData = null;
            if ($categoryId) {
                $categoryData = $category->load($categoryId);
                print_r($categoryData);
            }
            if($categoryData){
                $categoryPathId = $category->pathId;
                $parentId = $postData['parentId'];
                $parentData = $category->load($parentId);
                $newPath = $parentData->pathId.'='.$categoryId;
                $postData['pathId'] = $newPath;
                $category->categoryId = $categoryId;
                $category->setData($postData);
                $category->save();
                $category->updateChildrenPathIds($categoryPathId, $parentId, $categoryId);
            } else {
                if(array_key_exists('parentId', $postData)){
                   $parentId = $postData['parentId'];
                   $parentData = $category->load($parentId);
                   $parentPath = $parentData->pathId;
                } 
                $category->setData($postData);
                $id = $category->save();
                $category->load($id);
                if(!array_key_exists('parentId', $postData)){
                    $parentPath = $id;
                    $parentId = 0;
                }
                $category->parentId = $parentId;
                $category->pathId = $parentPath; 
                $category->save();
            }
            
            $grid = \Mage::getBlock('Block\Admin\Category\Grid')->toHtml();
            $response = [
                'element' => [
                    [
                        'selector' => '#tab',
                        'html' => null,
                    ],
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid,
                    ]
                ]                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);  
        }catch(Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    }

    public function deleteAction(){
        try{
            $category = \Mage::getModel('Model\Category');
            $categoryId = $this->getRequest()->getGet('id');
            if ($categoryId) {
                $category = $category->load($categoryId);
                if(!$category){
                    throw new Exception("Invalid id.");
                }
            }
            $pathId = $category->pathId;
            $parentId = $category->parentId;
            $category->updateChildrenPathIds($pathId, $parentId);
            $category->delete();
            $grid = Mage::getBlock('Block_Category_Grid')->toHtml();
            $response = [
                'element' => [
                    [
                        'selector' => '#tab',
                        'html' => null,
                    ],
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid,
                    ]
                ]
                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);
        }catch(Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    } 
}?>