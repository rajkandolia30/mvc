<?php 
namespace Controller\Admin\Attribute;
\Mage::loadFileByClassName('Controller\Core\Admin');
class Option extends \Controller\Core\Admin {
	protected $model = null;

	public function setModel(){
        try{
    		$this->model = \Mage::getModel('Model\Attribute\Option');
    		return $this;
        }catch (Exception $e){
            echo $e->getMessage();
        }
	}
    
	public function getModel(){
        try{
    		if(!$this->model){
    			$this->setModel();
    		}
    		return $this->model;
        } catch (Exception $e){
            echo $e->getMessage();
        }
	}
    
    public function gridAction(){
         $grid = \Mage::getBlock('Block\Admin\Attribute\Option\Edit')->toHtml();
            $response = [
                'element' =>[
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid,
                    ]
                ]                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);
    }

    public function saveAction(){
        try{
            $model = \Mage::getModel('Model\Attribute\Option');
            $attributeId = $this->getRequest()->getGet('id');
            $existData = $this->getRequest()->getPost('exist');
            $newData = $this->getRequest()->getPost('new');

            foreach ($newData as $key => $value) {
                if($key == 'name'){
                    $model->name = $value['0'];
                }
                if($key == 'sortOrder'){
                    $model->sortOrder = $value['0'];

                }
                $model->attributeId = $attributeId;
                $model->save();
            }

            foreach ($existData as $key => $value){
                    $name = $value['name'];
                    $sortOrder = $value['sortOrder'];
                    $model->name = $name;
                    $model->sortOrder = $sortOrder;
                    print_r($model);
                    $model->save();
            }

            /*$grid = \Mage::getBlock('Block\Admin\Attribute\Option\Edit')->toHtml();
            $response = [
                'element' => [
                    [
                        'selector' => '#tab',
                        'html' => null,
                    ],
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid,
                    ]
                ]                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);*/
        }catch(Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    }

    public function deleteAction(){
        try{
                        
            $grid = \Mage::getBlock('Block\Admin\Attirbute\Grid')->toHtml();
            $response = [
                'element' => [
                    [
                        'selector' => '#tab',
                        'html' => null,
                    ],
                    [
                        'selector' => '#contentHtml',
                        'html' => $grid,
                    ]
                ]
                
            ];
            header("Content-type: application/json; charset=utf-8");
            echo json_encode($response);
        }catch(Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    }
}
 ?>