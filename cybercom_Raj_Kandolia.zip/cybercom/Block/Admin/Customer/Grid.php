<?php
namespace Block\Admin\Customer;
\Mage::loadFileByClassName('Block\Core\Template');
class Grid extends \Block\Core\Template{
    protected $customers = [];

    public function __construct(){
        $this->setTemplate('./View/admin/customer/grid.php');
    }
    public function getCustomers() {
        if(!$this->customers){
            $this->setCustomers();
        }
        return $this->customers;
    }
    public function setCustomers($customers = null) {
        if(!$customers){
            $customer = \Mage::getModel('Model\Customer');
            $customers = $customer->fetchAll();
        }
        $this->customers = $customers;
        return $this;
    }
    
}

?>