<?php 
namespace Block\Admin\Product\Edit\Tabs;
\Mage::loadFileByClassName('Block\Core\Template');
class Attribute extends \Block\Core\Template{
 	protected $attributeOption = null;
 	
 	public function __construct(){
		parent::__construct();
 		$this->setTemplate('./View/admin/product/form/tabs/attribute.php');
 	}

 	public function setAttributeOption($attibuteOption = null){
 		if(!$this->attributeOption){
 			$attributeOption = \Mage::getModel('Model\Attribute\Option');
 			$id = $this->getRequest()->getGet('id');
 			if($id){
 				$attributeOption = $attributeOption->load($id);
 			}
 		}
 		$this->attributeOption = $attributeOption;
 		return $this;
 	}

 } ?>